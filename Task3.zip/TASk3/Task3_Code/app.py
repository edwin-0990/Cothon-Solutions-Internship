from flask import Flask, request, jsonify, render_template
import hashlib
import os

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

# Ensure upload folder exists
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])


# Password hashing function
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


# Password validation function
def validate_password(password):
    if len(password) < 8:
        return "Weak: Password must be at least 8 characters."
    if password.islower() or password.isupper() or password.isdigit():
        return "Medium: Add uppercase, lowercase, and digits for strength."
    return "Strong: Good password!"


# Check password in uploaded wordlist
def dictionary_attack(password, wordlist_path):
    with open(wordlist_path, 'r') as f:
        wordlist = [line.strip() for line in f.readlines()]
    return "Password found in wordlist!" if password in wordlist else "Password not found."


# Routes
@app.route('/')
def home():
    return render_template('index.html')


@app.route('/hash_password', methods=['GET', 'POST'])
def hash_password_page():
    if request.method == 'POST':
        password = request.form.get('password')
        hashed_password = hash_password(password)
        return render_template('hash_password.html', result=hashed_password)
    return render_template('hash_password.html', result=None)


@app.route('/dictionary_attack', methods=['GET', 'POST'])
def dictionary_attack_page():
    result = None
    if request.method == 'POST':
        password = request.form.get('password')
        uploaded_file = request.files.get('wordlist')
        if uploaded_file:
            wordlist_path = os.path.join(app.config['UPLOAD_FOLDER'], uploaded_file.filename)
            uploaded_file.save(wordlist_path)
            result = dictionary_attack(password, wordlist_path)
        else:
            result = "Please upload a wordlist file."
    return render_template('dictionary_attack.html', result=result)


@app.route('/check_strength', methods=['GET', 'POST'])
def check_strength_page():
    if request.method == 'POST':
        password = request.form.get('password')
        strength = validate_password(password)
        return render_template('check_strength.html', result=strength)
    return render_template('check_strength.html', result=None)


if __name__ == '__main__':
    app.run(debug=True)
