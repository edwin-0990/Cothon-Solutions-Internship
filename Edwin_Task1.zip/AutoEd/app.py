import subprocess
import os
import re
from flask import Flask, render_template, request, send_from_directory
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import schedule
import time
from datetime import datetime
from config import TOOLS, SCAN_TIMEOUT

app = Flask(__name__)

SCAN_RESULTS_PATH = 'scans/'

# Function to sanitize domain name for use as a folder name
def sanitize_folder_name(domain):
    return re.sub(r'[^\w\-.]', '_', domain)

# Function to run a specific tool scan and save results
def run_scan(tool, target, folder_path, scan_type_option):
    command = [TOOLS[tool]['command']] + scan_type_option.split() + [target]
    try:
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=SCAN_TIMEOUT)
        result_text = result.stdout.decode()
        error_text = result.stderr.decode()

        # Save the results to a file in the domain's folder
        file_name = f"{tool}.txt"
        with open(os.path.join(folder_path, file_name), 'w') as f:
            f.write(result_text if result_text else error_text)

        return result_text if result_text else error_text
    except subprocess.TimeoutExpired:
        return f"{tool} scan timed out after {SCAN_TIMEOUT} seconds."

# Function to generate a PDF report of the scan results
def generate_pdf_report(target, folder_path, results):
    pdf_file = os.path.join(folder_path, f'{sanitize_folder_name(target)}_report.pdf')
    c = canvas.Canvas(pdf_file, pagesize=letter)

    c.setFont("Helvetica-Bold", 16)
    c.drawString(30, 750, f"Scan Report for {target}")
    y_position = 730

    for tool, result in results.items():
        c.setFont("Helvetica-Bold", 12)
        c.drawString(30, y_position, f"{TOOLS[tool]['name']}:")
        y_position -= 20

        c.setFont("Helvetica", 10)
        for line in result.splitlines():
            c.drawString(30, y_position, line)
            y_position -= 12
            if y_position < 40:  # Handle page overflow
                c.showPage()
                c.setFont("Helvetica-Bold", 16)
                c.drawString(30, 750, f"Scan Report for {target}")
                y_position = 730

        y_position -= 20

    c.save()

# Function to schedule the scan
def schedule_scan(target, tools, scan_time):
    # Extract only the time (HH:MM) from the full datetime-local input
    job_time = datetime.strptime(scan_time, '%Y-%m-%dT%H:%M')  # Handles datetime-local input
    time_str = job_time.strftime('%H:%M')  # Format time as HH:MM

    # Define the function to run the scan at the scheduled time
    def run_scheduled_scan():
        sanitized_name = sanitize_folder_name(target)
        folder_path = os.path.join(SCAN_RESULTS_PATH, sanitized_name)
        os.makedirs(folder_path, exist_ok=True)

        results = {}
        for tool in tools:
            scan_type_option = TOOLS[tool]['scan_types']['default']
            results[tool] = run_scan(tool, target, folder_path, scan_type_option)

        generate_pdf_report(target, folder_path, results)

    # Schedule the scan
    schedule.every().day.at(time_str).do(run_scheduled_scan)

@app.route('/')
def index():
    return render_template('index.html', tools=TOOLS)

@app.route('/start_scan', methods=['POST'])
def start_scan():
    target = request.form['target'].strip()
    if not target:
        return render_template('index.html', tools=TOOLS, error="Please enter a valid domain or IP.")

    tools = request.form.getlist('tools')
    if not tools:
        return render_template('index.html', tools=TOOLS, error="Please select at least one tool.")

    sanitized_name = sanitize_folder_name(target)
    folder_path = os.path.join(SCAN_RESULTS_PATH, sanitized_name)
    os.makedirs(folder_path, exist_ok=True)

    results = {}
    for tool in tools:
        scan_type_option = request.form.get(f"{tool}_scan_type", TOOLS[tool]['scan_types']['default'])
        results[tool] = run_scan(tool, target, folder_path, scan_type_option)

    if request.form.get('generate_pdf') == 'yes':
        generate_pdf_report(target, folder_path, results)

    return render_template('scan_results.html', results=results, tools=TOOLS, target=target)

@app.route('/schedule_scan', methods=['POST'])
def schedule_scan_route():
    target = request.form['target']
    tools = request.form.getlist('tools')
    scan_time = request.form['scan_time']  # datetime-local input from the form

    # Schedule the scan with the fixed time format
    schedule_scan(target, tools, scan_time)

    return render_template('schedule_success.html', target=target, scan_time=scan_time)

@app.route('/scans/<path:filename>')
def download_file(filename):
    return send_from_directory(SCAN_RESULTS_PATH, filename)

@app.route('/scheduled_results')
def scheduled_results():
    # List all scanned directories
    scanned_dirs = os.listdir(SCAN_RESULTS_PATH)
    results = {}
    for folder in scanned_dirs:
        folder_path = os.path.join(SCAN_RESULTS_PATH, folder)
        if os.path.isdir(folder_path):
            # Collect files in each directory
            files = os.listdir(folder_path)
            results[folder] = files
    return render_template('scheduled_results.html', results=results)

if __name__ == '__main__':
    app.run(debug=True)
