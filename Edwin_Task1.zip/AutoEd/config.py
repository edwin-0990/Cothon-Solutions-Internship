TOOLS = {
    'nmap': {
        'name': 'Nmap Network Scanner',
        'command': 'nmap',
        'description': 'Discover hosts and services on a network.',
        'usage': 'Enter an IP address or domain. Example: example.com',
        'scan_types': {
            'default': '-sV',
            'aggressive': '-A',
            'os_detection': '-O'
        },
        'vulnerabilities': [
            {'vulnerability': 'Open Ports Detected', 'severity': 'High', 'mitigation': 'Block unused ports and implement firewalls.'}
        ]
    },
    'sqlmap': {
        'name': 'SQLMap',
        'command': 'sqlmap',
        'description': 'Detect and exploit SQL injection vulnerabilities.',
        'usage': 'Enter a full URL. Example: https://example.com/vulnerable-page',
        'scan_types': {
            'basic': '--batch',
            'crawl': '--crawl=3',
            'dbs': '--dbs'
        },
        'vulnerabilities': [
            {'vulnerability': 'SQL Injection Detected', 'severity': 'Critical', 'mitigation': 'Sanitize user inputs and use prepared statements.'}
        ]
    },
    'nuclei': {
        'name': 'Nuclei Vulnerability Scanner',
        'command': 'nuclei',
        'description': 'Identify vulnerabilities using template-based scanning.',
        'usage': 'Enter a full URL. Example: https://example.com',
        'scan_types': {
            'default': '',
            'critical': '-severity critical',
            'all': '-severity all'
        },
        'vulnerabilities': [
            {'vulnerability': 'XSS Vulnerability', 'severity': 'High', 'mitigation': 'Use proper input validation and output encoding.'}
        ]
    },
    'amass': {
        'name': 'Amass Subdomain Enumeration',
        'command': 'amass',
        'description': 'Enumerate subdomains of a target domain.',
        'usage': 'Enter a domain. Example: example.com',
        'scan_types': {
            'default': 'enum -d',
            'passive': 'enum -passive',
            'active': 'enum -active'
        },
        'vulnerabilities': [
            {'vulnerability': 'Subdomain Disclosure', 'severity': 'Medium', 'mitigation': 'Use DNS zone transfer restrictions and private subdomains.'}
        ]
    },
    'zap': {
        'name': 'OWASP ZAP',
        'command': 'zap-cli',
        'description': 'Find vulnerabilities in web applications.',
        'usage': 'Enter a full URL. Example: https://example.com',
        'scan_types': {
            'quick': 'quick-scan',
            'full': 'full-scan'
        },
        'vulnerabilities': [
            {'vulnerability': 'Cross-site Scripting (XSS)', 'severity': 'Critical', 'mitigation': 'Implement proper output encoding and input validation.'},
            {'vulnerability': 'Insecure Direct Object References (IDOR)', 'severity': 'High', 'mitigation': 'Implement proper access control and authorization mechanisms.'}
        ]
    },
    'dirbuster': {
        'name': 'DirBuster Directory Fuzzer',
        'command': 'dirbuster',
        'description': 'Brute force directories and file names on a web server.',
        'usage': 'Enter a URL. Example: https://example.com',
        'scan_types': {
            'default': '-u'
        },
        'vulnerabilities': [
            {'vulnerability': 'Hidden Directories/Files', 'severity': 'Medium', 'mitigation': 'Obfuscate directory names and limit access to sensitive files.'}
        ]
    },
    'gobuster': {
        'name': 'Gobuster Directory Fuzzer',
        'command': 'gobuster',
        'description': 'Discover directories and files on a web server.',
        'usage': 'Enter a URL. Example: https://example.com',
        'scan_types': {
            'dir': 'dir',
            'vhost': 'vhost'
        },
        'vulnerabilities': [
            {'vulnerability': 'Directory Traversal', 'severity': 'Medium', 'mitigation': 'Limit access to sensitive directories and configure web server settings properly.'}
        ]
    },
    'ffuf': {
        'name': 'FFUF Fast Web Fuzzer',
        'command': 'ffuf',
        'description': 'Fuzz files and directories on a web server.',
        'usage': 'Enter a URL. Example: https://example.com',
        'scan_types': {
            'default': '-u',
            'recursive': '-recursion'
        },
        'vulnerabilities': [
            {'vulnerability': 'Unsecured Endpoints', 'severity': 'High', 'mitigation': 'Use authentication and authorization mechanisms on sensitive endpoints.'}
        ]
    }
}

SCAN_TIMEOUT = 600  # Timeout in seconds
